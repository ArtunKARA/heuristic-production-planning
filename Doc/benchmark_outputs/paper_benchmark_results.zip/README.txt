Paper benchmark results (NP=20, example_input.json)
================================================================

Contents:
  paper_comparison_main_2/  — hho, hmpa, cssrank (540 jobs)
  paper_comparison_main_3/  — ga, tabu, gatabu, ga_tabu_inline, ga_tabu_topk (900 jobs)
  tables_report.xlsx        — merged 8-method Excel tables

Each run folder contains manifest.json, csv/, plots/.
Excluded from archive: runs/, state/, logs (regenerable / debug only).

To rebuild Excel locally:
  1. Unzip this file under Doc/benchmark_outputs/
  2. python Doc/build_tables_xlsx.py
